#!/usr/bin/env python
#
# ToggleRTS - Momentarily toggle the RTS pin of a serial port High and Low, to remotely power up an
#             Elecraft K3, K3S, KPA500, or KPA1500 via a keying transistor.
#
# Time-stamp: "26 March 2018 23:24 UTC"
#
# Usage:      ToggleRTS [COM port name or number] [duration in milleconds]
#
# Default:    COM1: 40 ms
#
# Connections:
#             1. DE-9 pin 7 (RTS) -> 1K resistor -> Base of NPN transistor (e.g. 2N2222)
#             2. Emitter of NPN transistor -> Ground
#             3. Collector of NPN transistor -> K3/K3S/KPA500/KPA1500 ACC/AUX Pin 8 (PWR ON)
#
# Usage:
#             o K3/K3S - Running this script turns the radio on by momentarily rounding pin 8
#               Send "PS0;" via K3 Utility or Macro to power K3 OFF
#
#             o KPA500/KPA1500 - Running this script toggles AMP ON or OFF
#
# Note:  requires PySerial package (https://pypi.python.org/pypi/pyserial/2.7)
#
# Written by N6TV

import serial                           # From pySerial serial port I/O package
from time import sleep                  # For sleep
from sys import exit, argv              # For exit and argv
from os import path, system             # For path.basename, os.system
from re import match                    # For match

# Function printUsage -- display help message
def printUsage():
    runName = path.basename(argv[0])
    print '\nThis program toggles the RTS pin of the specified COM port HIGH for n ms',\
          '\n\nUsage: ', runName.strip('.py'), '[COMx[:] | x] [n]',\
          '\n        Where x is COM port 1 - 99 (default 1), and n >= 1 (default 40 ms)',\
          '\n\n       ', runName.strip('.py'),\
          '[? | -? | -h | --help] (display this help text)'
    system('Pause')

# Function safeCast -- safely cast input argument or value to a type
def safe_cast(val, to_type, default=None):
    try:
        return to_type(val)
    except (ValueError, TypeError):
        return default

# Defaults
comPortName = 'COM1:'                   # Serial port to trigger RTS
duration = 40                           # Duration of pulse in milliseconds

# Mainline start, check arguments, if any
if len(argv) > 1:
    arg1 = argv[1].upper()
    if arg1 in ('?', '-?', '-H', '-HELP', '--HELP'):
        printUsage()
        exit(8)
    
    # See if first arg is an integer
    comPortNumber = safe_cast(arg1, int)
    
    # If first arg is not an integer, accept COM1[:] - COM99[:]
    if comPortNumber == None:
        # If COM port name specified, like COMxx: for COM1 to COM99
        if match('^[C][O][M][1-9][0-9]{0,1}[:]*$', arg1):
            if arg1.endswith(':'):
                comPortName = arg1
            else:
                comPortName = arg1 + ':'
        else:
            printUsage()
            exit(8)
    # Else if first arg is an integer, but out of range, print error and exit
    elif comPortNumber not in range(1,99):
        printUsage()
        exit(8)
    # Else make friendly COM port name COMx: from integer argument x
    else:
        comPortName = ('COM%d:' % comPortNumber).upper()

    # Get pulse duration from second arg
    if len(argv) > 2:
        arg2 = argv[2]
        # Accept only integer values > 1 ms 
        duration = safe_cast(arg2, int)
        if duration == None:
            printUsage()
            exit(8)
        elif duration < 1:
            printUsage()
            exit(8)

# Open the Serial port 19200,N,8,1 no handshake
try:
    # Must use UNC notation \\.\COM10 to handle COM10 or greater.  See
    # https://support.microsoft.com/en-us/help/115831/howto-specify-serial-ports-larger-than-com9
    uncPortName = '\\\\.\\'+ comPortName.strip(':')
    comPort = serial.Serial(uncPortName, 19200, rtscts=False, dsrdtr=False)
except IOError, err:
    print err
    system('Pause')
    exit(8)

print 'Toggling', comPortName, 'RTS high for', duration, 'ms ...'

# Keep DTR pin LOW
comPort.setDTR(False)

# Set RTS pin HIGH
comPort.setRTS(True)

# Sleep for specified duration in ms
sleep(duration/1000.0)

# Set RTS pin LOW
comPort.setRTS(False)

comPort.close()
