
This program toggles the DTR pin of the specified COM port HIGH for n ms 

Usage:  ToggleDTR [COMx[:] | x] [n] 
        Where x is COM port 1 - 99 (default 1), and n >= 1 (default 40 ms) 

        ToggleDTR [? | -? | -h | --help] (display this help text)

Installation:

	If you have Python 2.7 installed, install the PySerial package from
           https://pypi.python.org/pypi/pyserial/2.7
        and simply run ToggleDTR.py (contains complete source code)

        Otherwise, place all files in a directory in your PATH and run ToggleDTR.exe
        from a Windows Command Prompt, or create a Windows Shortcut with the 
        command line arguments as part of the target, e.g.

        Target:  C:\N6TV\ToggleDTR.exe COM1: 1000
